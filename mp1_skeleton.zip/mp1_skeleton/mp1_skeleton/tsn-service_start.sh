GLOG_logtostderr=1 ./tsd
